
## Rúbrica

### Reporte (inicio)
- **Título**: (0.25)
	- Breve y transmite el resultado ppal
- **Resumen** (0.5)
	- Un abstract. Unas 300 palabras
- **Introducción** (0.5)
	- Presenta en detalle antecedentes, motivación, y objetivos del estudio. Debe tener un párrafo resumen del pipeline de análisis aplicado (1000 palabras)

### Pipeline Analisis
- **Datos y análisis exploratorio** (1.75)
	- Descripción de los datos, exploración inicial, preprocesamiento y visualización
- **Análisis** (4)
	- Descripción de las tareas de análisis (supervisado, no supervisado, comparativas)
- **Discusión de resultados** (2)
	- tablas/figuras con los resultados obtenidos proponiéndose una interpretación de los mismos

### Reporte (final)
- **Conclusiones** (0.5)
	- Sección breve que dialogue con el resumen inicial a modo de conclusiones, relacionar resultados para responedr al objetivo planteado en la intro.
- **IA utilizada** (0.25)
	- Descripción de IA generativa utilizada, prompts, etc
- **Bibliografía**
	- Referencias a los datos, doc utilizada, otros códigos estudiados.
- **Se valorará positivamente profundizar en temáticas y técnicas no vistas en clase (filtros, wrapper, etc)**


## Preguntas
- Reporte : Documento? o documento + codigo?
- Análisis, cuantos mas mejor?
- uso IA
- explicabilidad modelo
- Idea/motivacion?
- Nota total
- Presentar repo? Powerpoint? 

## Idea de trabajo

**Exploración/preprocesado**
- Limpieza de nulos
- Selección de variables
	- R2
	- extra trees importance
	- CFS
- Visualizaciones
	- PCA / t-SNE
		- Base para clustering
- Desbalanceo de clases - como tratarlo
- Outliers 

**Supervisado**
- CLASiFICACION: Entrenar varios modelos CANDIDATE/FALSE POSITIVE:
	- Clasif. binaria
	- Tuning parametros (grid/bayesian)
		- caret tunegrid()
	- Comparativas
	- accuracy, recall, F1, matriz confusion, etc
	- análisis ROC
	- explicabilidad/importancia variables
- REGRESION: ¿?
- Deep Learning?

**No Supervisado**
- Clustering, agrupamos exoplanetas por sus características, que se verá luego?
	- Clustering: kmeans, jerárquico, DBSCAN
		- Tuning parametros (grid/bayesian)
		- Explicabilidad: explicar formacion de clusters
	- Elbow para encontrar mejor nº de clústers
	- Análisis de silouette para los resultados
		- Ver si planetas se clusterizan bien 
	- Problema: Que clústers?
		- agrupar planetas 
			- Tomar confirmados y hacerles clustering
				- HTML practica 5.2 clustering - ground truth
			- tomar todos y hacerlo tb para distinguir las clases
**Presentación**
- Introducción: Definir el problema

**Entrega**
- PDF memoria hablando + repo con código rmd
- CSV de datos